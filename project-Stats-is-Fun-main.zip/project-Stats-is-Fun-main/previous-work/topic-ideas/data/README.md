# Topic ideas: data sets

Put the candidate data sets in this folder.
